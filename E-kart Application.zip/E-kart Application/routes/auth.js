const express = require('express');
const authController = require('../controllers/auth');
const { check,body } = require('express-validator/check')
const bcrpyt = require('bcryptjs');

const router = express.Router();

router.get('/login', authController.getLogin);
router.get('/signup', authController.getSignup);
router.post('/login', 
            body('email')
            .isEmail()
            .withMessage('Please enter valid E-Mail id')
            .custom((value,{req}) => {
                return User.findOne({email:value})
                        .then(userDoc => {
                            if(userDoc){
                                return true;
                            }
                            throw new Error('E-Mail doesnt exist')
                        })
            })
            .normalizeEmail(),

            body('password','Please enter valid password')
            .isLength({min:3})
            .isAlphanumeric()
            .trim()
            
            , authController.postLogin);

const User = require('../models/user')

router.post(
    '/signup', 

    check('email')
    .isEmail()
    .withMessage('Please enter valid email')
    .custom((value,{req}) => {
        return User.findOne({email:value})
        .then(user => {
            if(user){
                return Promise.reject('E-Mail already exists. Try new one!!');
            }
            return true
        })
    })
    .normalizeEmail(),

    body(
        'password',
        'Please enter password with number and letters and with min 3 characters'
    )
    .isLength({min:3})
    .isAlphanumeric()
    .trim(),

    check('confirmPassword')
    .trim()
    .custom((value,{req}) => {
        if(value !== req.body.password){
            throw new Error('Password and Confirm Password is not equal')
        }
        return true;
    }),

    authController.postSignup);

router.post('/logout', authController.postLogout);

router.get('/reset',authController.getReset);

router.post('/reset',authController.postReset);

router.get('/reset/:token',authController.getNewPassword);
router.post('/new-password',authController.postNewPassword);

module.exports = router;