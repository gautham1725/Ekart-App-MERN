const path = require('path');

const express = require('express');
const {body,check} = require('express-validator/check');

const adminController = require('../controllers/admin');

const router = express.Router();
const auth = require('../middleware/is-auth');

// /admin/add-product => GET
router.get('/add-product', auth ,adminController.getAddProduct);

// /admin/products => GET
router.get('/products', auth ,adminController.getProducts);

// /admin/add-product => POST
router.post(
        '/add-product',

        auth, 

        body('title')
        .isString()
        .isLength({min:3})
        .trim(),

        // body('imageUrl')
        // .isURL(),

        body('price')
        .isFloat(),

        body('description')
        .isLength({min:5, max:200}),

        adminController.postAddProduct);

router.get('/edit-product/:productId',auth , adminController.getEditProduct);

router.post('/edit-product', 
            auth , 
            
            body('title')
            .isString()
            .isLength({min:3})
            .trim(),

            // body('imageUrl')
            // .isURL(),

            body('price')
            .isFloat(),

            body('description')
            .isLength({min:5, max:200}),

            
            adminController.postEditProduct);

router.post('/delete-product',auth , adminController.postDeleteProduct);

// router.delete('/product/:productId',auth , adminController.deleteProduct);

module.exports = router;
